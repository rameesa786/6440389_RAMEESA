// Log a welcome message to the console
console.log("Welcome to the Community Portal");

// Alert when the page is fully loaded
window.onload = function() {
    alert("Page is fully loaded. Welcome to the Community Portal!");
};
