module com.greetings {
    exports com.greetings;
}

module com.utils {
    exports com.utils;
}
