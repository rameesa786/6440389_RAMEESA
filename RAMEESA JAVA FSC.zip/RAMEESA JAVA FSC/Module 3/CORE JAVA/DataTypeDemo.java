public class DataTypeDemo {
    public static void main(String[] args) {
        // Declare and initialize different primitive data types
        int myInt = 25;
        float myFloat = 12.5f;
        double myDouble = 123.456;
        char myChar = 'J';
        boolean myBoolean = true;

        // Display the values
        System.out.println("Integer value: " + myInt);
        System.out.println("Float value: " + myFloat);
        System.out.println("Double value: " + myDouble);
        System.out.println("Character value: " + myChar);
        System.out.println("Boolean value: " + myBoolean);
    }
}
